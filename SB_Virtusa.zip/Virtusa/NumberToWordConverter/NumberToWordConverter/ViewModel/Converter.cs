﻿using System.ComponentModel;
using System.Windows;

namespace NumberToWordConverter
{
    //class Converter
    //{
    //}
    public class IOData : INotifyPropertyChanged
    {
        long inputNumber = 0;
        string output = "zero";
        public long InputNumber
        {
            get
            {
                return inputNumber;
            }
            set
            {
                inputNumber = value;                
                output = ConvertToWords(inputNumber);
                OnPropertyChanged(nameof(InputNumber));
                OnPropertyChanged(nameof(output));
            }
        }
        public string Output
        {
            get
            {
                return output;
            }
            set
            {
                output = value;
                OnPropertyChanged(nameof(Output));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public string ConvertToWords(long number)
        {
            if (number == 0) return "zero";
            string words = string.Empty;
            if ((number / 1000000) > 0)
            {
                words += ConvertToWords(number / 1000000) + " million ";
                number %= 1000000;
            }
            if ((number / 1000) > 0)
            {
                words += ConvertToWords(number / 1000) + " thousand and ";
                number %= 1000;
            }
            if ((number / 100) > 0)
            {
                words += ConvertToWords(number / 100) + " hundred and ";
                number %= 100;
            }
            if (number > 0)
            {
                var unitsArray = new[]
                {
                    "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"
                };
                var tensArray = new[]
                {
                    "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"
                };
                if (number < 20)
                {
                    words += unitsArray[number];
                }
                else
                {
                    words += tensArray[number / 10];
                    if ((number % 10) > 0)
                    {
                        words += " " + unitsArray[number % 10];
                    }
                }
            }
            return words;
        }

        
    }
    
   
    public partial class MainWindow: Window
        {
            IOData data = new IOData();
            public MainWindow()
            {
                InitializeComponent();
                this.DataContext = data;
            }
        }
    }

