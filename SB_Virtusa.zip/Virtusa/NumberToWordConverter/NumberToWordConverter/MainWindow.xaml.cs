﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NumberToWordConverter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //public MainWindow()
        //{
        //    InitializeComponent();
        //}
        private void btnLogin_Click_1(object sender, RoutedEventArgs e)
        {
            String message = "Invalid Credentials";
            try
            {
                string text = txtInNumber.Text.ToString();               
                long inputNumber;
                if (long.TryParse(text, out inputNumber) && inputNumber >= 0 && inputNumber <= 999999999)
                {

                }                
                else
                {
                    message = "1";
                }
            }
            catch (Exception ex)
            {
                message = ex.Message.ToString();
            }
            if (message == "1")
            {               
                MessageBox.Show("Please Enter Vaild Number Between 0 and 999999999", "Info");
            }
            else
            {

            }
        }
    }
}
